/*
 * Project10.java
 * 
 *   A program that plays and scores a round of the game Poker Dice.  In this game,
 *   five dice are rolled.  The player is allowed to select a number of those five dice
 *   to re-roll.  The dice are re-rolled and then scored as if they were a poker hand.  
 *   The following hands MUST be scored in this assignment:
 *   	* High card
 *   	* One Pair
 *   	* Two Pair
 *   	* Three of a Kind
 *   	* Full House
 *   	* Four of a Kind
 *   	* Five of a Kind
 *   For extra credit, you may also implement:
 *   	* Straight
 * 
 * @author Kelland Goodin
 * 
 */
package osu.cse1223;

import java.util.Scanner;

public class Project10 {

	public static void main(String[] args) {
		
		Scanner inScanner = new Scanner(System.in);
		int[] dice=new int[5];
		
		resetDice(dice);
		rollDice(dice);
		promptForReroll(dice,inScanner);
		System.out.println(getResult(dice));
		Scanner in = new Scanner(System.in);
		
		while(promptForPlayAgain(in)){
			resetDice(dice);
			rollDice(dice);
			System.out.println("");
			promptForReroll(dice,inScanner);
			System.out.println(getResult(dice));
		}
		
		System.out.println("");
		System.out.println("Goodbye!");
	}
	
	// Given an array of integers as input, sets every element of the array to zero.
	private static void resetDice(int[] dice) {
		
		for(int i = 0; i < dice.length; i++){
			dice[i] = 0;
		}
	}
	
	// Given an array of integers as input, checks each element of the array.  If the value
	// of that element is zero, generate a number between 1 and 6 and replace the zero with
	// it.  Otherwise, leave it as is and move to the next element.
	private static void rollDice(int[] dice) {
		
		for(int i = 0; i < dice.length; i++){
			if(dice[i] == 0){
				dice[i] =  (int)(6 * Math.random()) + 1;
			}
		}
	}
	
	// Given an array of integers as input, create a formatted String that contains the
	// values in the array in the order they appear in the array.  For example, if the 
	// array contains the values [0, 3, 6, 5, 2] then the String returned by this method
	// should be "0 3 6 5 2".
	private static String diceToString(int[] dice) {
		
		String diceString="";
		
		for(int i = 0; i < dice.length; i++){
			diceString = diceString + dice[i] + " ";
		}
		
		return diceString;
	}
	
	
	// Given an array of integers and a Scanner as input, prompt the user with a message
	// to indicate which dice should be re-rolled.  If the user enters a valid index (between
	// 0 and the total number of dice -1) then set the die at that index to zero.  If the 
	// user enters a -1, end the loop and return to the calling program.  If the user enters
	// any other invalid index, provide an error message and ask again for a valid index.
	private static void promptForReroll(int[] dice, Scanner inScanner) {
		
		String diceString=diceToString(dice);
		
		System.out.println("Your current dice: " + diceString);
		
		System.out.print("Select a die to re-roll (-1 to keep remaining dice): ");
		int userInput=inScanner.nextInt();
		
		while (userInput != -1){
			while (userInput > 4|| userInput < -1){
				System.out.println("Error: Index must be between 0 and 4 (-1 to quit)!");
				System.out.print("Select a die to re-roll (-1 to keep remaining dice): ");
				userInput=inScanner.nextInt();
			}
			if (userInput != -1){
			dice[userInput] = 0;
			diceString=diceToString(dice);
			System.out.println("Your current dice: " + diceString);
			System.out.print("Select a die to re-roll (-1 to keep remaining dice): ");
			userInput=inScanner.nextInt();
			}
		}
		System.out.println("Keeping remaining dice...");
		System.out.println("Rerolling...");
		
		rollDice(dice);
		diceString=diceToString(dice);
		System.out.println("Your final dice: " + diceString);
	}
	
	// Given a Scanner as input, prompt the user to play again.  The only valid entries
	// from the user are 'Y' or 'N', in either upper or lower case.  If the user enters
	// a 'Y' the method should return a value of true to the calling program.  If the user
	// enters a 'N' the method should return a value of false.  If the user enters anything
	// other than Y or N (including an empty line), an error message should be displayed
	// and the user should be prompted again until a valid response is received.
	private static boolean promptForPlayAgain(Scanner inScanner) {
		
		System.out.print("Would you like to play again [Y/N]?: ");
		String userInput = inScanner.nextLine();
		
		boolean play = false;
		
		while (userInput.charAt(0) != 'y' && (userInput.charAt(0) != 'Y') && (userInput.charAt(0) != 'N') && (userInput.charAt(0) != 'n')){
			System.out.println("ERROR! Only 'Y' or 'N' allowed as input!");
			System.out.print("Would you like to play again [Y/N]?: ");
			userInput = inScanner.nextLine();
		}
		if(userInput.equals("y") || (userInput.equals("Y"))){
			play = true; 
		}
		else{
			play = false;
		}
		return play;
	}
	
	// Given an array of integers, determines the result as a hand of Poker Dice.  The
	// result is determined as:
	//	* Five of a kind - all five integers in the array have the same value
	//	* Four of a kind - four of the five integers in the array have the same value
	//	* Full House - three integers in the array have the same value, and the remaining two
	//					integers have the same value as well (Three of a kind and a pair)
	//	* Three of a kind - three integers in the array have the same value
	//	* Two pair - two integers in the array have the same value, and two other integers
	//					in the array have the same value
	//	* One pair - two integers in the array have the same value
	//	* Highest value - if none of the above hold true, the Highest Value in the array
	//						is used to determine the result
	//
	//	The method should evaluate the array and return back to the calling program a String
	//  containing the score from the array of dice.
	//
	//  EXTRA CREDIT: Include in your scoring a Straight, which is 5 numbers in sequence
	//		[1,2,3,4,5] or [2,3,4,5,6].
	private static String getResult(int[] dice) {
		String hand = "";
		
		int[] count = getCounts(dice);
		
		int twoCount = 0;
		
		for(int i = 0; i < count.length; i++){
			if (count[i] == 2){
				twoCount++;
			}
			if(twoCount == 1){
				hand= "One Pair!";
			}
			if(twoCount == 2){
				hand="Two Pair!";
			}
		}
		int threeCount = 0;
		for(int i = 0; i < count.length; i++){
			if (count[i] == 3){
				threeCount++;
			}
		}
			if(threeCount == 1){
				hand = "Three of a Kind!";
			}
			if(threeCount == 1 && twoCount == 1){
				hand ="Full House!";
			}
		int fourCount = 0; 
		for(int i = 0; i < count.length; i++){
			if (count[i] == 4){
				fourCount++;
			}
			if(fourCount == 1){
				hand = "Four of a Kind!";
			}
		}
		int fiveCount = 0;
		for(int i = 0;i < count.length; i++){
			if (count[i] == 5){
				fiveCount++;
			}
			if(fiveCount == 1){
				hand ="Five of a Kind!";
			}
		}
		int highest = 0;
		
		if(hand.equals("")){
			for(int i = 0 ;i < dice.length; i++){
				if(dice[i] > highest){
					highest = dice[i];
				}
			}
			hand="Highest Card: " + highest;
		}
		return hand;
	}
	
	// Given an array of integers as input, return back an array with the counts of the
	// individual values in it.  You may assume that all elements in the array will have 
	// a value between 1 and 6.  For example, if the array passed into the method were:
	//   [1, 2, 3, 3, 5]
	// Then the array of counts returned back by this method would be:
	// [1, 1, 2, 0, 1, 0]
	// (Where index 0 holds the counts of the value 1, index 1 holds the counts of the value
	//  2, index 2 holds the counts of the value 3, etc.)
	// HINT:  This method is very useful for determining the score of a particular hand
	//  of poker dice.  Use it as a helper method for the getResult() method above.
	private static int[] getCounts(int[] dice) {
		int oneCount=0;
		
		int[] count=new int[6];
		for(int i=0;i<count.length;i++){
			count[i]=0;
		}
		for(int i=0;i<dice.length;i++){
			if (dice[i]==1){
				oneCount++;
			}
		}
		count[0]=oneCount;
		int twoCount=0;
		for(int i=0;i<dice.length;i++){
			if (dice[i]==2){
				twoCount++;
			}
		}
		count[1]=twoCount;
		int threeCount=0;
		for(int i=0;i<dice.length;i++){
			if (dice[i]==3){
				threeCount++;
			}
		}
		count[2]=threeCount;
		int fourCount=0;
		for(int i=0;i<dice.length;i++){
			if (dice[i]==4){
				fourCount++;
			}
		}
		count[3]=fourCount;
		int fiveCount=0;
		for(int i=0;i<dice.length;i++){
			if (dice[i]==5){
				fiveCount++;
			}
		}
		count[4]=fiveCount;
		int sixCount=0;
		for(int i=0;i<dice.length;i++){
			if (dice[i]==6){
				sixCount++;
			}
		}
		count[5]=sixCount;
		return count;
	}
}
